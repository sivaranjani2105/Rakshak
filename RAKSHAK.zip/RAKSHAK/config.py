# Shared AES-256 key (32 bytes) - must match simulator.py
# In production, load from secure storage / env
SECRET_KEY_B64 = "UkFLU0hBS01JTElUQVJZS0VZX18xNjI0MzIxMDAwMDA="  # base64 of 32-byte key
UDP_PORT = 5000
UDP_HOST = "0.0.0.0"
OLLAMA_BASE = "http://localhost:11434"
OLLAMA_MODEL = "llama2"  # Chat
OLLAMA_TRIAGE_MODEL = "llama3.2:3b"  # Triage/SitRep (small model for speed)

# Vitals thresholds for alerts
THRESHOLDS = {
    "heart_rate_min": 50,
    "heart_rate_max": 120,
    "temperature_min": 35.0,
    "temperature_max": 38.5,
    "spo2_min": 90,
}
