# RAKSHAK — Military Wearable Command Dashboard

Fully **offline** command dashboard for a military wearable system. No CDN, no external APIs.

## Requirements

- Python 3.8+
- [Ollama](https://ollama.ai) (optional, for chat) — run locally on `http://localhost:11434`

## Setup

```bash
pip install -r requirements.txt
```

## Run

1. **Start the dashboard** (Flask on port **5001**, UDP listener on port **5000**):

   ```bash
   python app.py
   ```

2. **Start the simulator** (sends encrypted UDP to `127.0.0.1:5000`):

   ```bash
   python simulator.py
   ```

3. Open **http://localhost:5001** in a browser.

**If you don't see the updated dashboard** (status bar, map, battery, Triage/SitRep buttons):
- **Stop** the Flask server (Ctrl+C in its terminal), then run `python app.py` again.
- **Hard-refresh** the browser: `Ctrl+Shift+R` (or `Ctrl+F5`). Or open the URL in a new private/incognito window.
- Ensure you visit **http://127.0.0.1:5001/** (root). The new UI is served from `/` and `/dashboard`.

4. (Optional) Install and run Ollama for the Command Query chat. Set `OLLAMA_MODEL` in `config.py` to your model name.

## Features

- **100% offline**: All assets (Chart.js, CSS, JS) in `/static`; system fonts only.
- **Encrypted UDP** on port 5000: AES-256 decryption; data displayed on soldier cards.
- **Soldier cards**: Heart rate, temperature, SpO2, alert status; updates every ~1.5 s.
- **HR trend chart**: Chart.js (local) for heart rate over time.
- **Alert panel**: Threshold alerts when vitals exceed limits (see `config.THRESHOLDS`).
- **Command Query**: Chat box sends to local Ollama and shows responses.

## Ports

| Service    | Port |
|-----------|------|
| UDP data  | 5000 |
| Flask app | 5001 |

## Config

Edit `config.py` for AES key (must match simulator), thresholds, and Ollama base URL/model.
