/**
 * RAKSHAK Dashboard - Offline military wearable command.
 * Features: Status summary bar, position map, battery, triage, sitrep, buddy alerts.
 * All logic runs on polled /api/soldiers and /api/alerts. No CDN.
 */
(function () {
  "use strict";

  const POLL_INTERVAL_MS = 1500;
  // Vitals thresholds (match backend config)
  const HR_MIN = 50, HR_MAX = 120;
  const TEMP_MIN = 35, TEMP_MAX = 38.5, TEMP_CAUTION_HI = 38, TEMP_CRITICAL_HI = 38.5;
  const SPO2_MIN = 90, SPO2_CAUTION = 95, SPO2_CRITICAL = 92; // SpO2 < 90 = alert; < 95 = caution; < 92 = critical
  const HR_CAUTION_HI = 120, HR_CRITICAL_HI = 140;
  // Buddy system: distance in grid units
  const BUDDY_PROXIMITY_THRESHOLD = 2.0;
  const BUDDY_STATIONARY_SECONDS = 30;
  // Map: grid -5..+5 each axis, 400x400 canvas
  const MAP_SIZE = 400;
  const MAP_GRID_MIN = -5;
  const MAP_GRID_MAX = 5;

  let hrChart = null;
  let chartDatasets = {};
  // Feature 6: track first time each soldier was seen stationary (for 30s rule)
  let stationarySince = {};

  function byId(id) {
    return document.getElementById(id);
  }

  function updateClock() {
    const el = byId("clock");
    if (el) el.textContent = new Date().toTimeString().slice(0, 8);
  }
  setInterval(updateClock, 1000);
  updateClock();

  function setOnline(online) {
    const status = byId("connectionStatus");
    const bar = document.querySelector(".status-bar");
    if (status) status.textContent = online ? "LIVE — UDP :5000" : "OFFLINE — Awaiting UDP on :5000";
    if (bar) bar.classList.toggle("online", !!online);
  }

  /**
   * Feature 1: Classify soldier as "ok" | "caution" | "critical" for status bar and map.
   * OK: all vitals normal (HR 50-120, temp 35-38, SpO2 >= 95%), no critical stationary.
   * Caution: HR > 120 but < 140, or temp > 38 but < 38.5, or SpO2 < 95% but > 92%.
   * Critical: HR >= 140 or temp >= 38.5 or SpO2 < 92% or fall/stationary alert.
   */
  function getSoldierStatus(s) {
    const hr = s.heart_rate;
    const temp = s.temperature;
    const spo2 = s.spo2;
    const stationary = !!s.stationary;

    if (hr != null && hr >= HR_CRITICAL_HI) return "critical";
    if (temp != null && temp >= TEMP_CRITICAL_HI) return "critical";
    if (spo2 != null && spo2 < SPO2_CRITICAL) return "critical";
    if (hr != null && hr < HR_MIN) return "critical";
    if (temp != null && temp < TEMP_MIN) return "critical";
    if (stationary) return "critical"; // immobility treated as critical for status

    if (hr != null && hr > HR_CAUTION_HI && hr < HR_CRITICAL_HI) return "caution";
    if (temp != null && temp > TEMP_CAUTION_HI && temp < TEMP_CRITICAL_HI) return "caution";
    if (spo2 != null && spo2 < SPO2_CAUTION && spo2 >= SPO2_CRITICAL) return "caution";

    return "ok";
  }

  /**
   * Feature 1: Update status summary bar counts and DOM.
   */
  function updateStatusSummaryBar(soldiers) {
    let ok = 0, caution = 0, critical = 0;
    if (soldiers && soldiers.length) {
      soldiers.forEach(function (s) {
        const st = getSoldierStatus(s);
        if (st === "ok") ok++;
        else if (st === "caution") caution++;
        else critical++;
      });
    }
    const elOk = byId("countOk");
    const elCaution = byId("countCaution");
    const elCritical = byId("countCritical");
    if (elOk) elOk.textContent = ok;
    if (elCaution) elCaution.textContent = caution;
    if (elCritical) elCritical.textContent = critical;
  }

  function isAlert(s) {
    const hr = s.heart_rate, temp = s.temperature, spo2 = s.spo2;
    if (hr != null && (hr < HR_MIN || hr > HR_MAX)) return true;
    if (temp != null && (temp < TEMP_MIN || temp > TEMP_MAX)) return true;
    if (spo2 != null && spo2 < SPO2_MIN) return true;
    return false;
  }

  function vitalClass(val, min, max) {
    if (val == null) return "";
    if (val < min || val > max) return "danger";
    if (val <= min + (max - min) * 0.1 || val >= max - (max - min) * 0.1) return "warn";
    return "";
  }

  /**
   * Feature 3: Battery display in card. Use battery field from payload; low < 20% gets .battery-low class.
   */
  function renderSoldierCards(soldiers) {
    const container = byId("soldierCards");
    if (!container) return;
    if (!soldiers || soldiers.length === 0) {
      container.innerHTML = "<p class=\"text-dim\">No soldier data yet. Start the simulator.</p>";
      return;
    }
    container.innerHTML = soldiers.map(function (s) {
      const statusTier = getSoldierStatus(s);
      const alert = isAlert(s);
      const hr = s.heart_rate != null ? s.heart_rate : "—";
      const temp = s.temperature != null ? s.temperature.toFixed(1) : "—";
      const spo2 = s.spo2 != null ? s.spo2 : "—";
      const battery = s.battery != null ? Math.max(0, Math.min(100, Math.round(s.battery))) : "—";
      const batteryLow = typeof battery === "number" && battery < 20;
      const hrCl = vitalClass(s.heart_rate, HR_MIN, HR_MAX);
      const tempCl = vitalClass(s.temperature, TEMP_MIN, TEMP_MAX);
      const spo2Cl = s.spo2 != null && s.spo2 < SPO2_MIN ? "danger" : "";
      const status = alert ? "ALERT — Check vitals" : "OK";
      const statusCl = alert ? "alert-msg" : "";
      const batteryCl = batteryLow ? "battery battery-low" : "battery";
      const batteryLabel = typeof battery === "number" ? battery + "%" : battery;
      return (
        "<div class=\"soldier-card " + (alert ? "alert" : "") + " status-" + statusTier + "\" data-id=\"" + (s.soldier_id || "") + "\">" +
        "<div class=\"id\">" + (s.soldier_id || "—") + "</div>" +
        "<div class=\"vitals\">" +
        "<div class=\"vital\"><span class=\"label\">HR</span><span class=\"value " + hrCl + "\">" + hr + "</span></div>" +
        "<div class=\"vital\"><span class=\"label\">Temp</span><span class=\"value " + tempCl + "\">" + temp + " °C</span></div>" +
        "<div class=\"vital\"><span class=\"label\">SpO2</span><span class=\"value " + spo2Cl + "\">" + spo2 + "%</span></div>" +
        "<div class=\"vital\"><span class=\"label\">Status</span><span class=\"value\">" + (s.alert_status || "—") + "</span></div>" +
        "<div class=\"vital battery-row\"><span class=\"label\">\uD83D\uDD0B</span><span class=\"" + batteryCl + "\" title=\"Battery level\">" + batteryLabel + "</span></div>" +
        "</div>" +
        "<div class=\"status-line " + statusCl + "\">" + status + "</div>" +
        "</div>"
      );
    }).join("");
  }

  /**
   * Feature 2: Draw position grid (10x10, 1km x 1km). Base at center (0,0). Soldiers as colored dots from POS_X, POS_Y.
   */
  function drawPositionMap(soldiers) {
    const canvas = byId("positionCanvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = MAP_SIZE;
    const h = MAP_SIZE;
    const gridMin = MAP_GRID_MIN;
    const gridMax = MAP_GRID_MAX;
    const gridRange = gridMax - gridMin;

    // Clear and background
    ctx.fillStyle = "#141a14";
    ctx.fillRect(0, 0, w, h);

    // Grid lines
    ctx.strokeStyle = "#2a3a2a";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 10; i++) {
      const x = (i / 10) * w;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
      const y = (i / 10) * h;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // Base camp at center (0,0)
    const baseX = w / 2;
    const baseY = h / 2;
    ctx.fillStyle = "#7a8a7a";
    ctx.beginPath();
    ctx.arc(baseX, baseY, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#c8d4c8";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = "#c8d4c8";
    ctx.font = "10px Consolas, monospace";
    ctx.textAlign = "center";
    ctx.fillText("BASE", baseX, baseY - 12);

    // Map grid coords to pixel: grid -5..+5 -> 0..w, 0..h (y flipped so +Y is up)
    function toPixel(gx, gy) {
      const px = ((gx - gridMin) / gridRange) * w;
      const py = h - ((gy - gridMin) / gridRange) * h;
      return { x: px, y: py };
    }

    const statusColors = { ok: "#2dff2d", caution: "#ffaa00", critical: "#ff4444" };
    (soldiers || []).forEach(function (s) {
      const gx = parseFloat(s.pos_x);
      const gy = parseFloat(s.pos_y);
      if (Number.isNaN(gx) || Number.isNaN(gy)) return;
      const clampedX = Math.max(gridMin, Math.min(gridMax, gx));
      const clampedY = Math.max(gridMin, Math.min(gridMax, gy));
      const p = toPixel(clampedX, clampedY);
      const tier = getSoldierStatus(s);
      const color = statusColors[tier] || statusColors.ok;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#0d120d";
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = "#c8d4c8";
      ctx.font = "11px Consolas, monospace";
      ctx.textAlign = "center";
      ctx.fillText(s.soldier_id || "", p.x, p.y + 20);
    });
  }

  function ensureChartCanvas() {
    const canvas = byId("hrChart");
    return (canvas && window.Chart) ? canvas : null;
  }

  function updateHrChart(soldiers) {
    if (!soldiers || soldiers.length === 0) return;
    const canvas = ensureChartCanvas();
    if (!canvas) return;
    const colors = ["#2dff2d", "#00aaff", "#ffaa00", "#aa00ff"];
    const datasets = [];
    soldiers.forEach(function (s, i) {
      const sid = s.soldier_id || "S" + i;
      const history = s.hr_history || [];
      const color = colors[i % colors.length];
      if (!chartDatasets[sid]) {
        chartDatasets[sid] = { id: sid, label: sid, data: [], borderColor: color, backgroundColor: color + "20", fill: true, tension: 0.3 };
      }
      chartDatasets[sid].data = history.map(function (p, idx) { return { x: idx, y: p.y }; });
      datasets.push(chartDatasets[sid]);
    });
    if (!hrChart) {
      hrChart = new Chart(canvas, {
        type: "line",
        data: { datasets: datasets },
        options: {
          responsive: true,
          maintainAspectRatio: true,
          scales: {
            x: { grid: { color: "#2a3a2a" }, ticks: { color: "#7a8a7a", maxTicksLimit: 12 } },
            y: { min: Math.max(0, HR_MIN - 10), max: HR_MAX + 10, grid: { color: "#2a3a2a" }, ticks: { color: "#7a8a7a" } }
          },
          plugins: { legend: { labels: { color: "#c8d4c8" } } }
        }
      });
    } else {
      hrChart.data.datasets = datasets;
      hrChart.update("none");
    }
  }

  /**
   * Feature 6: Buddy alerts. Check proximity (distance < BUDDY_PROXIMITY_THRESHOLD).
   * If soldier A is near B and A has been stationary for BUDDY_STATIONARY_SECONDS, add buddy alert.
   * stationarySince[sid] = timestamp when we first saw stationary; if now - stationarySince >= 30s, trigger.
   */
  function checkBuddyAlerts(soldiers, serverAlerts) {
    const now = Date.now() / 1000;
    const alertsOut = (serverAlerts || []).slice();
    if (!soldiers || soldiers.length < 2) return alertsOut;

    soldiers.forEach(function (a) {
      const ax = parseFloat(a.pos_x);
      const ay = parseFloat(a.pos_y);
      if (Number.isNaN(ax) || Number.isNaN(ay) || !a.stationary) return;
      if (!stationarySince[a.soldier_id]) stationarySince[a.soldier_id] = now;
      const duration = now - stationarySince[a.soldier_id];
      if (duration < BUDDY_STATIONARY_SECONDS) return;

      soldiers.forEach(function (b) {
        if (a.soldier_id === b.soldier_id) return;
        const bx = parseFloat(b.pos_x);
        const by = parseFloat(b.pos_y);
        if (Number.isNaN(bx) || Number.isNaN(by)) return;
        const dist = Math.sqrt((ax - bx) * (ax - bx) + (ay - by) * (ay - by));
        if (dist < BUDDY_PROXIMITY_THRESHOLD) {
          alertsOut.push({
            soldier_id: a.soldier_id,
            type: "buddy",
            message: "Buddy Alert: " + a.soldier_id + " (near " + b.soldier_id + ") is immobile. Check on them.",
            timestamp: now
          });
        }
      });
    });
    // Reset stationary timer when not stationary
    soldiers.forEach(function (s) {
      if (!s.stationary) stationarySince[s.soldier_id] = undefined;
    });
    return alertsOut;
  }

  function renderAlerts(soldiers, alertsList) {
    const combined = checkBuddyAlerts(soldiers, alertsList);
    const placeholder = byId("alertPlaceholder");
    const list = byId("alertList");
    if (!placeholder || !list) return;
    if (!combined || combined.length === 0) {
      placeholder.style.display = "block";
      list.innerHTML = "";
      return;
    }
    placeholder.style.display = "none";
    list.innerHTML = combined.slice(-25).reverse().map(function (a) {
      const time = a.timestamp ? new Date(a.timestamp * 1000).toLocaleTimeString() : "";
      const msg = a.type === "buddy" ? a.message : (a.message || "") + " (" + (a.value != null ? a.value : "") + ")";
      const cls = a.type === "buddy" ? "buddy-alert" : "";
      return "<li class=\"" + cls + "\"><span class=\"sid\">" + (a.soldier_id || "?") + "</span> <span class=\"msg\">" + msg + "</span> " + time + "</li>";
    }).join("");
    // Optional: highlight soldier cards mentioned in buddy alerts
    document.querySelectorAll(".soldier-card").forEach(function (card) {
      card.classList.remove("buddy-highlight");
      combined.forEach(function (a) {
        if (a.type === "buddy" && (a.message.indexOf(card.dataset.id) !== -1)) card.classList.add("buddy-highlight");
      });
    });
  }

  function poll() {
    fetch("/api/soldiers")
      .then(function (r) { return r.json(); })
      .then(function (data) {
        const soldiers = data.soldiers || [];
        setOnline(soldiers.length > 0);
        updateStatusSummaryBar(soldiers);
        renderSoldierCards(soldiers);
        drawPositionMap(soldiers);
        updateHrChart(soldiers);
        return soldiers;
      })
      .then(function (soldiers) {
        fetch("/api/alerts").then(function (r) { return r.json(); }).then(function (d) {
          renderAlerts(soldiers, d.alerts || []);
        }).catch(function () {});
      })
      .catch(function () { setOnline(false); });
  }

  poll();
  setInterval(poll, POLL_INTERVAL_MS);

  /* Feature 4: Triage - Suggest Evacuation Order */
  const btnTriage = byId("btnTriage");
  const triageResult = byId("triageResult");
  if (btnTriage && triageResult) {
    btnTriage.addEventListener("click", function () {
      triageResult.textContent = "Requesting evacuation order...";
      triageResult.className = "ai-result-bubble loading";
      triageResult.setAttribute("aria-live", "polite");
      fetch("/api/triage", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (j.error) throw new Error(j.error);
          triageResult.textContent = j.response || "(No response)";
          triageResult.className = "ai-result-bubble";
        })
        .catch(function (e) {
          triageResult.textContent = "Error: " + (e.message || "Request failed");
          triageResult.className = "ai-result-bubble error";
        });
    });
  }

  /* Feature 5: SitRep */
  const btnSitrep = byId("btnSitrep");
  const sitrepResult = byId("sitrepResult");
  if (btnSitrep && sitrepResult) {
    btnSitrep.addEventListener("click", function () {
      sitrepResult.textContent = "Generating situation report...";
      sitrepResult.className = "ai-result-bubble loading";
      fetch("/api/sitrep", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (j.error) throw new Error(j.error);
          sitrepResult.textContent = j.response || "(No response)";
          sitrepResult.className = "ai-result-bubble";
        })
        .catch(function (e) {
          sitrepResult.textContent = "Error: " + (e.message || "Request failed");
          sitrepResult.className = "ai-result-bubble error";
        });
    });
  }

  /* Chat */
  const chatMessages = byId("chatMessages");
  const chatInput = byId("chatInput");
  const chatSend = byId("chatSend");

  function addChatMsg(content, role, isError) {
    if (!chatMessages) return;
    const div = document.createElement("div");
    div.className = "msg " + (role === "user" ? "user" : isError ? "error" : "bot");
    div.textContent = content;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function sendChat() {
    const msg = (chatInput && chatInput.value || "").trim();
    if (!msg) return;
    if (chatSend) chatSend.disabled = true;
    if (chatInput) chatInput.value = "";
    addChatMsg(msg, "user");
    fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: msg }) })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || "Request failed"); return j; }); })
      .then(function (j) { addChatMsg(j.response || "(no response)", "bot"); })
      .catch(function (e) { addChatMsg(e.message || "Error", "bot", true); })
      .finally(function () { if (chatSend) chatSend.disabled = false; });
  }
  if (chatSend) chatSend.addEventListener("click", sendChat);
  if (chatInput) chatInput.addEventListener("keydown", function (e) { if (e.key === "Enter") sendChat(); });
})();
