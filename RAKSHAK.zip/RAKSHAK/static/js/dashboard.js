(function () {
  "use strict";

  const POLL_INTERVAL_MS = 1500;
  const HR_MIN = 50, HR_MAX = 120, TEMP_MIN = 35, TEMP_MAX = 38.5, SPO2_MIN = 90;

  let hrChart = null;
  let chartDatasets = {};

  function byId(id) {
    return document.getElementById(id);
  }

  function updateClock() {
    const el = byId("clock");
    if (!el) return;
    const now = new Date();
    el.textContent = now.toTimeString().slice(0, 8);
  }
  setInterval(updateClock, 1000);
  updateClock();

  function setOnline(online) {
    const status = byId("connectionStatus");
    const bar = document.querySelector(".status-bar");
    if (status) status.textContent = online ? "LIVE — UDP :5000" : "OFFLINE — Awaiting UDP on :5000";
    if (bar) bar.classList.toggle("online", online);
  }

  function isAlert(s) {
    const hr = s.heart_rate;
    const temp = s.temperature;
    const spo2 = s.spo2;
    if (hr != null && (hr < HR_MIN || hr > HR_MAX)) return true;
    if (temp != null && (temp < TEMP_MIN || temp > TEMP_MAX)) return true;
    if (spo2 != null && spo2 < SPO2_MIN) return true;
    return false;
  }

  function vitalClass(val, min, max) {
    if (val == null) return "";
    if (val < min || val > max) return "danger";
    if (val <= min + (max - min) * 0.1 || val >= max - (max - min) * 0.1) return "warn";
    return "";
  }

  function renderSoldierCards(soldiers) {
    const container = byId("soldierCards");
    if (!container) return;
    if (!soldiers || soldiers.length === 0) {
      container.innerHTML = "<p class=\"text-dim\">No soldier data yet. Start the simulator.</p>";
      return;
    }
    container.innerHTML = soldiers.map(function (s) {
      const alert = isAlert(s);
      const hr = s.heart_rate != null ? s.heart_rate : "—";
      const temp = s.temperature != null ? s.temperature.toFixed(1) : "—";
      const spo2 = s.spo2 != null ? s.spo2 : "—";
      const hrCl = vitalClass(s.heart_rate, HR_MIN, HR_MAX);
      const tempCl = vitalClass(s.temperature, TEMP_MIN, TEMP_MAX);
      const spo2Cl = s.spo2 != null && s.spo2 < SPO2_MIN ? "danger" : "";
      const status = alert ? "ALERT — Check vitals" : "OK";
      const statusCl = alert ? "alert-msg" : "";
      return (
        "<div class=\"soldier-card " + (alert ? "alert" : "") + "\" data-id=\"" + (s.soldier_id || "") + "\">" +
        "<div class=\"id\">" + (s.soldier_id || "—") + "</div>" +
        "<div class=\"vitals\">" +
        "<div class=\"vital\"><span class=\"label\">HR</span><span class=\"value " + hrCl + "\">" + hr + "</span></div>" +
        "<div class=\"vital\"><span class=\"label\">Temp</span><span class=\"value " + tempCl + "\">" + temp + " °C</span></div>" +
        "<div class=\"vital\"><span class=\"label\">SpO2</span><span class=\"value " + spo2Cl + "\">" + spo2 + "%</span></div>" +
        "<div class=\"vital\"><span class=\"label\">Status</span><span class=\"value\">" + (s.alert_status || "—") + "</span></div>" +
        "</div>" +
        "<div class=\"status-line " + statusCl + "\">" + status + "</div>" +
        "</div>"
      );
    }).join("");
  }

  function ensureChartCanvas() {
    const canvas = byId("hrChart");
    if (!canvas || !window.Chart) return null;
    return canvas;
  }

  function updateHrChart(soldiers) {
    if (!soldiers || soldiers.length === 0) return;
    const canvas = ensureChartCanvas();
    if (!canvas) return;

    const colors = ["#2dff2d", "#00aaff", "#ffaa00", "#aa00ff"];
    const labels = [];
    const datasets = [];

    soldiers.forEach(function (s, i) {
      const sid = s.soldier_id || "S" + i;
      const history = s.hr_history || [];
      const color = colors[i % colors.length];
      if (!chartDatasets[sid]) {
        chartDatasets[sid] = { id: sid, label: sid, data: [], borderColor: color, backgroundColor: color + "20", fill: true, tension: 0.3 };
      }
      const data = history.map(function (p, idx) {
        return { x: idx, y: p.y };
      });
      chartDatasets[sid].data = data;
      datasets.push(chartDatasets[sid]);
    });

    if (!hrChart) {
      hrChart = new Chart(canvas, {
        type: "line",
        data: { datasets: datasets },
        options: {
          responsive: true,
          maintainAspectRatio: true,
          scales: {
            x: {
              grid: { color: "#2a3a2a" },
              ticks: { color: "#7a8a7a", maxTicksLimit: 12 }
            },
            y: {
              min: Math.max(0, HR_MIN - 10),
              max: HR_MAX + 10,
              grid: { color: "#2a3a2a" },
              ticks: { color: "#7a8a7a" }
            }
          },
          plugins: {
            legend: { labels: { color: "#c8d4c8" } }
          }
        }
      });
    } else {
      hrChart.data.datasets = datasets;
      hrChart.update("none");
    }
  }

  function renderAlerts(alertsList) {
    const placeholder = byId("alertPlaceholder");
    const list = byId("alertList");
    if (!placeholder || !list) return;
    if (!alertsList || alertsList.length === 0) {
      placeholder.style.display = "block";
      list.innerHTML = "";
      return;
    }
    placeholder.style.display = "none";
    list.innerHTML = alertsList.slice(-20).reverse().map(function (a) {
      const time = a.timestamp ? new Date(a.timestamp * 1000).toLocaleTimeString() : "";
      return "<li><span class=\"sid\">" + (a.soldier_id || "?") + "</span> <span class=\"msg\">" + (a.message || "") + " (" + (a.value != null ? a.value : "") + ")</span> " + time + "</li>";
    }).join("");
  }

  function poll() {
    fetch("/api/soldiers")
      .then(function (r) { return r.json(); })
      .then(function (data) {
        const soldiers = data.soldiers || [];
        setOnline(soldiers.length > 0);
        renderSoldierCards(soldiers);
        updateHrChart(soldiers);
      })
      .catch(function () { setOnline(false); });

    fetch("/api/alerts")
      .then(function (r) { return r.json(); })
      .then(function (data) { renderAlerts(data.alerts || []); })
      .catch(function () {});
  }

  poll();
  setInterval(poll, POLL_INTERVAL_MS);

  /* Chat */
  const chatMessages = byId("chatMessages");
  const chatInput = byId("chatInput");
  const chatSend = byId("chatSend");

  function addChatMsg(content, role, isError) {
    if (!chatMessages) return;
    const div = document.createElement("div");
    div.className = "msg " + (role === "user" ? "user" : isError ? "error" : "bot");
    div.textContent = content;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function sendChat() {
    const msg = (chatInput && chatInput.value || "").trim();
    if (!msg) return;
    if (chatSend) chatSend.disabled = true;
    if (chatInput) chatInput.value = "";
    addChatMsg(msg, "user");

    fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: msg })
    })
      .then(function (r) {
        return r.json().then(function (j) {
          if (!r.ok) throw new Error(j.error || "Request failed");
          return j;
        });
      })
      .then(function (j) {
        addChatMsg(j.response || "(no response)", "bot");
      })
      .catch(function (e) {
        addChatMsg(e.message || "Error", "bot", true);
      })
      .finally(function () {
        if (chatSend) chatSend.disabled = false;
      });
  }

  if (chatSend) chatSend.addEventListener("click", sendChat);
  if (chatInput) chatInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") sendChat();
  });
})();
