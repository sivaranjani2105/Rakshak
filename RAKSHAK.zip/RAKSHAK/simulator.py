"""
RAKSHAK Simulator — Generates fake soldier vitals and sends encrypted UDP packets.
Includes: vitals, position (dead reckoning), battery, stationary flag, motion.
Run while the dashboard (app.py) is running. UDP target: localhost:5000.
All assets/data are local; no external APIs.
"""
import base64
import json
import random
import socket
import time
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

# Must match app/config.py
SECRET_KEY_B64 = "UkFLU0hBS01JTElUQVJZS0VZX18xNjI0MzIxMDAwMDA="
UDP_HOST = "127.0.0.1"
UDP_PORT = 5000

# Simulate 3 soldiers with varying vitals, motion, battery, and positions
SOLDIER_IDS = ["S01", "S02", "S03"]

# Vitals ranges (realistic variation)
HR_RANGE = (58, 125)
TEMP_RANGE = (35.2, 38.8)
SPO2_RANGE = (85, 100)

# Dead reckoning: grid -5 to +5 (1km x 1km relative to base at 0,0). Step size per tick.
POS_STEP = 0.08
# Battery: drop 1% every 60 simulated seconds. At ~1.5s per tick, 40 ticks ≈ 60s.
BATTERY_TICKS_PER_PERCENT = 40
# Stationary: if motion magnitude below this for STATIONARY_TICKS_THRESHOLD ticks, set stationary=True
MOTION_THRESHOLD = 0.02
STATIONARY_TICKS_THRESHOLD = 20


def get_cipher():
    key = base64.b64decode(SECRET_KEY_B64)
    return AES.new(key, AES.MODE_ECB)


def encrypt_payload(obj: dict) -> bytes:
    plain = json.dumps(obj).encode("utf-8")
    cipher = get_cipher()
    padded = pad(plain, AES.block_size)
    encrypted = cipher.encrypt(padded)
    return base64.b64encode(encrypted)


# Per-soldier state for dead reckoning, battery, and stationary
soldier_state = {}


def get_or_init_state(soldier_id: str) -> dict:
    """Initialize or return state for a soldier: pos_x, pos_y, motion_x, motion_y, battery, stationary_ticks."""
    if soldier_id not in soldier_state:
        # Start near center with small random offset
        soldier_state[soldier_id] = {
            "pos_x": random.uniform(-1.0, 1.0),
            "pos_y": random.uniform(-1.0, 1.0),
            "motion_x": 0.0,
            "motion_y": 0.0,
            "battery": 100.0,
            "tick_count": 0,
            "stationary_ticks": 0,
        }
    return soldier_state[soldier_id]


def update_position_and_motion(soldier_id: str) -> tuple:
    """
    Update position using dead reckoning (slow random walk). Returns (pos_x, pos_y, motion_x, motion_y, stationary).
    Simulates IMU-derived movement: small random acceleration, then integrate to position.
    """
    state = get_or_init_state(soldier_id)
    state["tick_count"] += 1
    tick = state["tick_count"]

    # Random walk: add small random change to velocity (simulating noisy IMU)
    state["motion_x"] += random.uniform(-0.015, 0.015)
    state["motion_y"] += random.uniform(-0.015, 0.015)
    # Slight drag so they don't drift forever
    state["motion_x"] *= 0.98
    state["motion_y"] *= 0.98
    # Clamp velocity magnitude
    cap = 0.12
    mx, my = state["motion_x"], state["motion_y"]
    mag = (mx * mx + my * my) ** 0.5
    if mag > cap:
        state["motion_x"] = mx * cap / mag
        state["motion_y"] = my * cap / mag

    # Update position (dead reckoning)
    state["pos_x"] += state["motion_x"] * POS_STEP * 10
    state["pos_y"] += state["motion_y"] * POS_STEP * 10
    # Keep within grid -5 to +5
    state["pos_x"] = max(-5.0, min(5.0, state["pos_x"]))
    state["pos_y"] = max(-5.0, min(5.0, state["pos_y"]))

    # Stationary: low motion for several ticks
    mag_now = (state["motion_x"] ** 2 + state["motion_y"] ** 2) ** 0.5
    if mag_now < MOTION_THRESHOLD:
        state["stationary_ticks"] = state.get("stationary_ticks", 0) + 1
    else:
        state["stationary_ticks"] = 0
    stationary = state["stationary_ticks"] >= STATIONARY_TICKS_THRESHOLD

    return (
        round(state["pos_x"], 2),
        round(state["pos_y"], 2),
        round(state["motion_x"], 4),
        round(state["motion_y"], 4),
        stationary,
    )


def update_battery(soldier_id: str) -> float:
    """Decrease battery by 1% every BATTERY_TICKS_PER_PERCENT ticks. Returns current battery 0-100."""
    state = get_or_init_state(soldier_id)
    tick = state["tick_count"]
    if tick > 0 and tick % BATTERY_TICKS_PER_PERCENT == 0:
        state["battery"] = max(0, state["battery"] - 1.0)
    return round(state["battery"], 1)


def generate_soldier(soldier_id: str) -> dict:
    """
    Generate one packet: vitals, position (POS_X, POS_Y), battery (BATTERY), stationary (STATIONARY),
    and motion_x, motion_y for optional use. Three soldiers with varying vitals.
    """
    pos_x, pos_y, motion_x, motion_y, stationary = update_position_and_motion(soldier_id)
    battery = update_battery(soldier_id)

    # Vary vitals by soldier: S01 more stable, S02 moderate, S03 more volatile
    idx = SOLDIER_IDS.index(soldier_id) if soldier_id in SOLDIER_IDS else 0
    if idx == 0:
        hr = random.randint(65, 95)
        temp = round(random.uniform(36.2, 37.0), 1)
        spo2 = random.randint(96, 100)
    elif idx == 1:
        hr = random.randint(70, 115)
        temp = round(random.uniform(36.5, 38.2), 1)
        spo2 = random.randint(92, 99)
        if random.random() < 0.1:
            hr = random.randint(121, 135)
            spo2 = random.randint(88, 94)
    else:
        hr = random.randint(58, 125)
        temp = round(random.uniform(35.8, 38.8), 1)
        spo2 = random.randint(85, 100)
        if random.random() < 0.12:
            hr = random.choice([random.randint(40, 49), random.randint(130, 145)])
        if random.random() < 0.08:
            temp = round(random.uniform(38.6, 39.5), 1)
        if random.random() < 0.08:
            spo2 = random.randint(82, 89)

    status = "OK" if (50 <= hr <= 120 and 35 <= temp <= 38.5 and spo2 >= 90) else "ALERT"

    return {
        "soldier_id": soldier_id,
        "heart_rate": hr,
        "temperature": temp,
        "spo2": spo2,
        "alert_status": status,
        "timestamp": time.time(),
        # Feature 2: position (dead reckoning)
        "pos_x": pos_x,
        "pos_y": pos_y,
        # Feature 3: battery 0-100
        "battery": battery,
        # Feature 6: stationary flag (immobility)
        "stationary": stationary,
        # Optional: raw motion for debugging
        "motion_x": motion_x,
        "motion_y": motion_y,
    }


def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    print("RAKSHAK Simulator — Sending encrypted UDP to {}:{}".format(UDP_HOST, UDP_PORT))
    print("3 soldiers (S01, S02, S03) with vitals, position, battery, stationary. Press Ctrl+C to stop.\n")
    try:
        while True:
            for sid in SOLDIER_IDS:
                payload = generate_soldier(sid)
                encrypted = encrypt_payload(payload)
                sock.sendto(encrypted, (UDP_HOST, UDP_PORT))
            time.sleep(1.5)
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        sock.close()


if __name__ == "__main__":
    main()
