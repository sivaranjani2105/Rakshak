"""
RAKSHAK - Offline Military Wearable Command Dashboard
Flask backend: UDP listener (AES-256 decrypt), API, Ollama chat/triage/sitrep proxy.
"""
import base64
import json
import socket
import threading
import time
from collections import deque
from flask import Flask, render_template, jsonify, request
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import requests

import config

app = Flask(__name__)

# In-memory store: soldier_id -> { latest payload, history for charts }
soldier_data = {}
# Keep last 60 HR readings per soldier for chart
HR_HISTORY_LEN = 60
soldier_hr_history = {}
# Recent alerts (last 50)
alerts = deque(maxlen=50)
# Lock for thread-safe updates
data_lock = threading.Lock()

# Ollama model for triage/sitrep (small model for speed)
OLLAMA_TRIAGE_MODEL = getattr(config, "OLLAMA_TRIAGE_MODEL", "llama3.2:3b")


def get_cipher():
    key = base64.b64decode(config.SECRET_KEY_B64)
    return AES.new(key, AES.MODE_ECB)


def decrypt_payload(encrypted_b64: bytes) -> dict:
    try:
        raw = base64.b64decode(encrypted_b64)
        cipher = get_cipher()
        decrypted = unpad(cipher.decrypt(raw), AES.block_size)
        return json.loads(decrypted.decode("utf-8"))
    except Exception as e:
        return {"_decrypt_error": str(e)}


def check_thresholds(payload: dict) -> list:
    out = []
    sid = payload.get("soldier_id", "?")
    hr = payload.get("heart_rate")
    temp = payload.get("temperature")
    spo2 = payload.get("spo2")
    if hr is not None:
        if hr < config.THRESHOLDS["heart_rate_min"]:
            out.append({"soldier_id": sid, "type": "heart_rate", "value": hr, "message": "HR below minimum"})
        elif hr > config.THRESHOLDS["heart_rate_max"]:
            out.append({"soldier_id": sid, "type": "heart_rate", "value": hr, "message": "HR above maximum"})
    if temp is not None:
        if temp < config.THRESHOLDS["temperature_min"]:
            out.append({"soldier_id": sid, "type": "temperature", "value": temp, "message": "Temp below minimum"})
        elif temp > config.THRESHOLDS["temperature_max"]:
            out.append({"soldier_id": sid, "type": "temperature", "value": temp, "message": "Temp above maximum"})
    if spo2 is not None and spo2 < config.THRESHOLDS["spo2_min"]:
        out.append({"soldier_id": sid, "type": "spo2", "value": spo2, "message": "SpO2 below minimum"})
    return out


def udp_listener():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((config.UDP_HOST, config.UDP_PORT))
    while True:
        try:
            data, _ = sock.recvfrom(65535)
            if not data:
                continue
            payload = decrypt_payload(data)
            if "_decrypt_error" in payload:
                continue
            sid = payload.get("soldier_id")
            if not sid:
                continue
            with data_lock:
                soldier_data[sid] = payload
                if sid not in soldier_hr_history:
                    soldier_hr_history[sid] = deque(maxlen=HR_HISTORY_LEN)
                hr = payload.get("heart_rate")
                if hr is not None:
                    soldier_hr_history[sid].append({"t": time.time(), "y": hr})
                for a in check_thresholds(payload):
                    a["timestamp"] = time.time()
                    alerts.append(a)
        except Exception:
            pass


def _get_soldiers_for_api():
    """Return list of soldiers with hr_history for API (caller must hold data_lock or call from route that does)."""
    out = []
    for sid, p in list(soldier_data.items()):
        entry = dict(p)
        entry["hr_history"] = list(soldier_hr_history.get(sid, []))
        out.append(entry)
    return out


@app.route("/")
def index():
    # Serve main dashboard (index.html with all 6 features)
    return render_template("index.html")


@app.route("/dashboard")
def dashboard():
    # Legacy route: same as index
    return render_template("index.html")


@app.route("/api/soldiers")
def api_soldiers():
    with data_lock:
        return jsonify({"soldiers": _get_soldiers_for_api()})


@app.route("/api/alerts")
def api_alerts():
    with data_lock:
        return jsonify({"alerts": list(alerts)})


@app.route("/api/chat", methods=["POST"])
def api_chat():
    body = request.get_json() or {}
    message = (body.get("message") or "").strip()
    if not message:
        return jsonify({"error": "No message"}), 400
    try:
        r = requests.post(
            f"{config.OLLAMA_BASE}/api/generate",
            json={"model": config.OLLAMA_MODEL, "prompt": message, "stream": False},
            timeout=30,
        )
        r.raise_for_status()
        data = r.json()
        response_text = data.get("response", "")
        return jsonify({"response": response_text})
    except requests.exceptions.ConnectionError:
        return jsonify({"error": "Ollama not reachable. Is it running on localhost:11434?"}), 503
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# --- Feature 4: Triage Assistant ---
@app.route("/api/triage", methods=["POST"])
def api_triage():
    """Suggest evacuation order based on current soldier vitals using local Ollama."""
    with data_lock:
        soldiers = _get_soldiers_for_api()
    if not soldiers:
        return jsonify({"error": "No soldier data available."}), 400
    # Build minimal JSON for prompt (no hr_history)
    data_for_prompt = []
    for s in soldiers:
        data_for_prompt.append({
            "soldier_id": s.get("soldier_id"),
            "heart_rate": s.get("heart_rate"),
            "temperature": s.get("temperature"),
            "spo2": s.get("spo2"),
            "stationary": s.get("stationary"),
            "battery": s.get("battery"),
            "pos_x": s.get("pos_x"), "pos_y": s.get("pos_y"),
        })
    prompt = (
        "Based on heart rate, SpO2, temperature, and immobility (stationary flag), "
        "rank these soldiers for evacuation priority. Explain briefly. "
        "Current data (JSON): " + json.dumps(data_for_prompt)
    )
    try:
        r = requests.post(
            f"{config.OLLAMA_BASE}/api/generate",
            json={"model": OLLAMA_TRIAGE_MODEL, "prompt": prompt, "stream": False},
            timeout=60,
        )
        r.raise_for_status()
        response_text = r.json().get("response", "")
        return jsonify({"response": response_text})
    except requests.exceptions.ConnectionError:
        return jsonify({"error": "Ollama not reachable. Start Ollama on localhost:11434."}), 503
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# --- Feature 5: SitRep ---
@app.route("/api/sitrep", methods=["POST"])
def api_sitrep():
    """Generate a concise situation report for the squad using Ollama."""
    with data_lock:
        soldiers = _get_soldiers_for_api()
    if not soldiers:
        return jsonify({"error": "No soldier data available."}), 400
    data_for_prompt = []
    for s in soldiers:
        data_for_prompt.append({
            "soldier_id": s.get("soldier_id"),
            "heart_rate": s.get("heart_rate"),
            "temperature": s.get("temperature"),
            "spo2": s.get("spo2"),
            "stationary": s.get("stationary"),
            "battery": s.get("battery"),
            "pos_x": s.get("pos_x"), "pos_y": s.get("pos_y"),
        })
    prompt = (
        "Generate a concise situation report for the squad based on current health, "
        "location, and alerts. Include overall status, any critical soldiers, and recommendations. "
        "Data: " + json.dumps(data_for_prompt)
    )
    try:
        r = requests.post(
            f"{config.OLLAMA_BASE}/api/generate",
            json={"model": OLLAMA_TRIAGE_MODEL, "prompt": prompt, "stream": False},
            timeout=60,
        )
        r.raise_for_status()
        response_text = r.json().get("response", "")
        return jsonify({"response": response_text})
    except requests.exceptions.ConnectionError:
        return jsonify({"error": "Ollama not reachable. Start Ollama on localhost:11434."}), 503
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    t = threading.Thread(target=udp_listener, daemon=True)
    t.start()
    app.run(host="0.0.0.0", port=5001, debug=False, use_reloader=False)
